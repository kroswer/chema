# Sensor IR

Este proyecto es un sistema para una RPi, que tiene un sensor RI que al ser activado ocasiona que la tarjeta actue enviando un tuit utilizando la API de twitter.

Por favor, revise el manual tecnico para mayor información. 

[Manual técnico](https://github.com/cerelacrox/bichoIR/blob/master/ManualTecnico.md)
